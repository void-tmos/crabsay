run("cp /tmp/crabsay/crabsay.py /py/crabsay.py")
